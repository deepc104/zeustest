<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

date_default_timezone_set('Asia/Kolkata');

class Admin extends CI_Controller
{
    public function __construct()
    {
         parent::__construct();
         $this->load->library('grocery_CRUD');
		 $this->load->library('form_validation');
    }
	
	public function _example_output($output = null){
		$this->load->view('admin_list',$output);
	}

	function index(){
		try{
			$crud = new grocery_CRUD();
			$crud->set_theme('datatables');
			$crud->set_table('tblusers');
			$crud->set_subject('User');
			$crud->columns('uid', 'fname', 'lname','password','emailid', 'dob', 'city', 'usertype', 'userstatus', 'modified_date', 'created_date');

			$crud->display_as('uid','UserID')
				 ->display_as('fname','First Name')
				 ->display_as('lname','Last Name')
				 ->display_as('emailid','Email')
				 ->display_as('dob','DOB')
				 ->display_as('city','City')
				 ->display_as('usertype','User Type')
				 ->display_as('userstatus','User status')
				 ->display_as('modified_date','Updated On')
				 ->display_as('created_date','Created On');
				 
			$crud->required_fields('fname', 'lname', 'emailid', 'password', 'dob', 'city', 'usertype', 'userstatus');
            $crud->unique_fields(array('emailid'));
            $crud->field_type('password', 'password');
			$crud->change_field_type('modified_date','invisible');
			$crud->change_field_type('created_date','invisible');
			
			$crud->set_rules('fname', 'First Name', 'trim|max_length[25]|required');
			$crud->set_rules('lname', 'Last Name', 'trim|max_length[25]|required');
			//$crud->set_rules('description', 'Description', 'trim|max_length[255]');
			$crud->set_rules('emailid', 'Email', 'trim|valid_email|max_length[255]');
			//$crud->set_rules('address', 'Address', 'trim|required|max_length[255]');								
			$crud->callback_before_insert(array($this,'beforeinsert_callback'));
			$crud->callback_before_update(array($this,'beforeupdate_callback'));
			$crud->callback_edit_field('password',array($this,'decrypt_password_callback'));

			$crud->unset_print();
			$crud->unset_export();
			$output = $crud->render();
			
			$this->_example_output($output);
			
		}catch(Exception $e){

			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}
	
	function beforeinsert_callback($post_array, $primary_key = null){ 
	    if($post_array['password'] <> '******'){
			$post_array['password'] = md5(trim($post_array['password']));
		}else{  unset($post_array['password']); }
		$post_array['modified_date'] = date('Y-d-m H:i:s');
		$post_array['created_date'] = date('Y-d-m H:i:s');

	    return $post_array;
	}
	
	function beforeupdate_callback($post_array, $primary_key = null){
	     if($post_array['password'] <> '******'){
			$post_array['password'] = md5(trim($post_array['password']));
		}else{  unset($post_array['password']); }
		$post_array['modified_date'] = date('Y-d-m H:i:s');

	    return $post_array;
	} 	
	
	function decrypt_password_callback($value)
	{
		return "<input type='password' name='password' value='******' autocomplete='off' />";
	}
	
}
?>