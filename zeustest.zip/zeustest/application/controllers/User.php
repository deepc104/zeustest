<?php date_default_timezone_set('Asia/Kolkata'); 

class User extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('form','url'));
        $this->load->library(array('session', 'form_validation', 'email'));
        $this->load->database();
        $this->load->model('user_model');
		$this->load->helper('security');
    }
	
	 function index()
    {
        $this->login();
    }
	 
	function login(){
		$this->load->view('templates/header');
		
		if (isset($this->session->userdata['logged_in'])) {
			if($this->session->userdata['logged_in']['role'] == "SuperAdmin" && $this->session->userdata['logged_in']['ustatus'] == "Active"){
				redirect('admin');
			}else{
				redirect('user/profile');
			}
		}else{
			$this->load->view('login_view');
		}
		$this->load->view('templates/footer');
	}

	// Check for user login process
	public function user_login_process() {
		$this->form_validation->set_rules('txtemail', 'txtemail', 'trim|required');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');

		if ($this->form_validation->run() == FALSE) {
			if(isset($this->session->userdata['logged_in'])){
				if($this->session->userdata['logged_in']['role'] == "SuperAdmin" && $this->session->userdata['logged_in']['ustatus'] == "Active"){
					 redirect('admin');
				}else{
				     redirect('user/profile');
					 
				}
			}else{
				$this->load->view('templates/header');
				$this->load->view('login_view');
				$this->load->view('templates/footer');
			}
		} else {
			$data = array(
			'txtemail' => $this->input->post('txtemail'),
			'password' => $this->input->post('password')
			);
			$result = $this->user_model->login($data);
			if ($result == TRUE) {
				$username = $this->input->post('txtemail');
				$result = $this->user_model->read_user_information($username);
				if ($result != false) {
					$session_data = array(
					'userid' => $result[0]->uid,
					'fname' => $result[0]->fname,
					'lname' => $result[0]->lname,
					'email' => $result[0]->emailid,
					'city' => $result[0]->city,
					'role' => $result[0]->usertype,
					'dob' => $result[0]->dob,
					'ustatus' => $result[0]->userstatus,
					'createdon' => $result[0]->created_date,
					);
					// Add user data in session
					$this->session->set_userdata('logged_in', $session_data);
					if($result[0]->usertype == "SuperAdmin" && $result[0]->userstatus == "Active"){
						redirect('admin');
					}else{
						redirect('user/profile');
					}
				}
			} else {
				$data = array(
				'error_message' => 'Invalid email id or password'
				);
				$this->load->view('templates/header');
				$this->load->view('login_view', $data);
				$this->load->view('templates/footer');
			}
		}
	}

	// Logout from admin page
	public function logout() {
		// Removing session data
		$sess_array = array(
			'email' => ''
		);
		$this->session->unset_userdata('logged_in', $sess_array);
		$data['message_display'] = 'Successfully Logout';
		$this->load->view('templates/header');
		$this->load->view('login_view', $data);
		$this->load->view('templates/footer');
	}
	
	function profile(){
	   $this->load->view('myprofile');
	}
	
}
?>