<?php
if (isset($this->session->userdata['logged_in'])) {
	header("location: ".base_url()."user/user_login_process");
}
?>

<?php
if (isset($logout_message)) {
	echo "<div class='message'>";
	echo $logout_message;
	echo "</div>";
}
?>
<?php
	if (isset($message_display)) {
	echo "<div class='message'>";
	echo $message_display;
	echo "</div>";
}
?>
<div id="main">
	<div id="login">
	<h2>Login Form</h2>
	<hr/>
	<?php 
	  $qstr = (isset($_GET['q']) and $_GET['q'] <> "") ? "?q=".$_GET['q'] : NULL;
	?>
	<?php echo form_open('user/user_login_process'.$qstr); ?>
		<?php
	echo "<div class='error_msg'>";
	if (isset($error_message)) {
		echo $error_message;
	}
		echo validation_errors();
		echo "</div>";
	?>
	<div class="form-group">
	<label for="txtemail">Email Id:</label>
	<input type="text" name="txtemail" id="txtemail" placeholder="Email"/>
	</div>
	<div class="form-group">
	<label>Password :</label>
	<input type="password" name="password" id="password" placeholder="**********"/>
	</div>
	
	<div class="form-group">
	<input type="submit" value=" Login " name="submit" class="fg-button teal"/>
	</div>
	<hr>
	<br />
	
	<?php echo form_close(); ?>
	</div>
</div>