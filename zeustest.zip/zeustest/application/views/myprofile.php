<?php
if (isset($this->session->userdata['logged_in'])) {
	if($this->session->userdata['logged_in']['role'] == "SuperAdmin"){
		redirect('admin');
	}
}else{
	 redirect('user/login');
} 

$uname = $this->session->userdata['logged_in']['fname']." ".$this->session->userdata['logged_in']['lname'];
$email = $this->session->userdata['logged_in']['email'];
$city = $this->session->userdata['logged_in']['city'];
$role = $this->session->userdata['logged_in']['role'];
$created_date = $this->session->userdata['logged_in']['createdon'];
$dob = $this->session->userdata['logged_in']['dob'];
?>
<head>
<title>My Profile</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/style.css">
</head>
<?php if(isset($uname) && ($uname <> "")){ ?>
	<div class="header">
	    <div class="left">
		  <h1>Welcome to Dashboard</h1>
		</div>
		<div class="right">
			<?php echo "Hello <b id='welcome'><i>" . $uname . "</i> !</b>";?>&nbsp;&nbsp;|&nbsp;&nbsp;<b id="logout"><a href="<?php echo base_url(); ?>index.php/user/logout">Logout</a></b>
		</div
	 </div>
<?php } ?>
<div class="userhome">
   <div id='usercontent'>
       <h3>Profile Details</h3>
		<div><span class='lefttext'>Name: </span><span class='righttext'><?=$uname;?></span></div> 
		<div><span class='lefttext'>Email: </span><span class='righttext'><?=$email;?></span></div> 	
		<div><span class='lefttext'>City: </span><span class='righttext'><?=$city;?></span></div>
		<div><span class='lefttext'>Date Of Birth: </span><span class='righttext'><?=$dob;?></span></div>
		<div><span class='lefttext'>Role: </span><span class='righttext'><?=$role;?></span></div> 	
		<div><span class='lefttext'>Created Date: </span><span class='righttext'><?=$created_date;?></span></div> 	
    </div>
 </div>
</body>
</html>