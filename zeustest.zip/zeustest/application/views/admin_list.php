<?php
if (isset($this->session->userdata['logged_in'])) {
	if($this->session->userdata['logged_in']['role'] == "SuperAdmin"){
		$username = $this->session->userdata['logged_in']['fname']." ".$this->session->userdata['logged_in']['lname'];
		$email = $this->session->userdata['logged_in']['email'];
	}else{
		 redirect('myprofile');
	}
}else{
	 redirect('user/login');
} 
?>
<head>
<title>Admin | List Page</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/style.css">
<?php foreach($css_files as $file): ?>
	<link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
<?php endforeach; 
  foreach($js_files as $file): ?>
	<script src="<?php echo $file; ?>"></script>
<?php endforeach; ?>
</head>
<?php if(isset($username) && ($username <> "")){ ?>
	<div class="header">
	    <div class="left">
		  <h1>Welcome to Admin Panel</h1>
		</div>
		<div class="right">
			<?php echo "Hello <b id='welcome'><i>" . $username . "</i> !</b>";?>&nbsp;&nbsp;|&nbsp;&nbsp;<b id="logout"><a href="<?php echo base_url(); ?>index.php/user/logout">Logout</a></b>
		</div>
	 </div>
<?php } ?>
<div class="adminhome">
   <div id='admincontent'>
       <h3>List Users</h3>
		<?php echo $output; ?>
	</div>
 </div>
</body>
</html>