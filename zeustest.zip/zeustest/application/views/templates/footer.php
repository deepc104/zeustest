    </div><!-- #content -->
	<div id="popupmain">
	   <div class="popupwrap">
		 <a href="javascript:void(0)" onclick="closepopup();" class="close-btn"></a>
		 <div class="popbody"></div> 
		<div>
	<div>
	<script src="<?=base_url();?>assets/js/jquery-1.11.2.min.js" type="text/javascript" language="javascript"></script> 
	<script src="<?=base_url();?>assets/js/common.js" type="text/javascript" language="javascript"></script>

</body>
</html>