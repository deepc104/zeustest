<?php
if (isset($this->session->userdata['logged_in'])) {
	$username = ($this->session->userdata['logged_in']['name']);
	$email = ($this->session->userdata['logged_in']['email']);
} else {
 // header("location: login");
}
?>

<html>
<head>
<title>Career</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />
<link href='http://fonts.googleapis.com/css?family=Raleway:500,600,700' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/style.css">
</head>
<body>
<div id='content'>
<?php if(isset($username) && ($username <> "")){ ?>
	<div header>
		<div id="profile">
			<?php echo "Hello <b id='welcome'><i>" . $username . "</i> !</b>";?>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="<?php echo base_url(); ?>index.php/user/logout">Logout</a>
		</div>
	 </div>
<?php } ?>

