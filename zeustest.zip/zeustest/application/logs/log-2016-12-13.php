<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-13 12:06:07 --> Severity: Notice --> Undefined property: Shopping::$db D:\xampp\htdocs\Deepika\cex\system\core\Model.php 77
ERROR - 2016-12-13 12:06:07 --> Severity: error --> Exception: Call to a member function get() on null D:\xampp\htdocs\Deepika\cex\application\models\billing_model.php 8
ERROR - 2016-12-13 12:06:08 --> Severity: Notice --> Undefined property: Shopping::$db D:\xampp\htdocs\Deepika\cex\system\core\Model.php 77
ERROR - 2016-12-13 12:06:08 --> Severity: error --> Exception: Call to a member function get() on null D:\xampp\htdocs\Deepika\cex\application\models\billing_model.php 8
ERROR - 2016-12-13 12:06:09 --> Severity: Notice --> Undefined property: Shopping::$db D:\xampp\htdocs\Deepika\cex\system\core\Model.php 77
ERROR - 2016-12-13 12:06:09 --> Severity: error --> Exception: Call to a member function get() on null D:\xampp\htdocs\Deepika\cex\application\models\billing_model.php 8
ERROR - 2016-12-13 12:06:09 --> Severity: Notice --> Undefined property: Shopping::$db D:\xampp\htdocs\Deepika\cex\system\core\Model.php 77
ERROR - 2016-12-13 12:06:09 --> Severity: error --> Exception: Call to a member function get() on null D:\xampp\htdocs\Deepika\cex\application\models\billing_model.php 8
